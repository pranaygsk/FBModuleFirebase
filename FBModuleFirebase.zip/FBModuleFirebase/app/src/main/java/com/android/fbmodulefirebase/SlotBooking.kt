package com.android.fbmodulefirebase

data class SlotBooking(
    val arrayList: ArrayList<String>)
